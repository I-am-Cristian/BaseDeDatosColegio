--- TuplasNoOK

--- TuplasNoOK

--- Usuario con correo NO institucional (viola restricción de tupla sobre dominio)
INSERT INTO Usuario VALUES (
    30, 'Pedro Cruz', DATE '2020-01-01', 'pedro.cruz@gmail.com',
    'Experiencia general'
);

--- Estudiante con correo informado pero sin teléfono (viola restricción de tupla)
INSERT INTO Estudiante VALUES (
    502, 40154321, 'Juana Silva', DATE '2009-02-10', 'Cra 100 #20-20', NULL,
    'juana.silva@correo.com', 201, 301, 11
);

--- Documento tipo 'TI' con número diferente de 10 dígitos (viola restricción de tupla)
INSERT INTO Documentos VALUES (
    40154321, 'TI', 12345678, DATE '2010-03-01', 'Manizales', 501
);
