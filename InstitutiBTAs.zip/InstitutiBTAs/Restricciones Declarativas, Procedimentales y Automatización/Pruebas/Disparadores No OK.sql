---Disparadores No OK

--- Intentar insertar una calificación cuya evaluación fue hace solo 5 días
--- DEBE FALLAR con error -20001
INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (TRUNC(SYSDATE) - 5, 3, 3, XMLType('<opinion>Muy pronto</opinion>'));

--- Intentar actualizar una calificación cuando NO es exactamente 2 días después
--- DEBE FALLAR con error -20002

UPDATE Calificacion
SET Opinion = XMLType('<opinion>Intento fuera de tiempo</opinion>')
WHERE Profesor = 2 AND Asignatura = 2;
