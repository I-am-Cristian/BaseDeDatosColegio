--Acciones OK

-- Insertar asignatura
INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (10, 'Matemáticas');

-- Insertar profesor
INSERT INTO Profesor (Especializacion, Contrato, Usuario, opinion)
VALUES ('Matemáticas', 'DF', 2001, 'Excelente');

-- Insertar calificacion relacionada
INSERT INTO Calificacion (Profesor, Asignatura, FechaEvaluacion, Nota)
VALUES (2001, 10, SYSDATE, 4.5);

-- Ahora eliminamos la asignatura y se elimina calificacion 
DELETE FROM Asignatura WHERE AsignaturaID = 10;



-- Insertar estudiante
INSERT INTO Estudiante (EstudianteID, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura)
VALUES (4001, 'Camila', TO_DATE('2012-05-12', 'YYYY-MM-DD'), 'Calle 1', 3112233445, 'camila@mail.com', 1, 555, 20);

-- Insertar documento asociado
INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (501, 'TI', 1234567890, TO_DATE('2019-01-10', 'YYYY-MM-DD'), 'Bogotá', 4001);

-- Eliminar el estudiante y el documento 
DELETE FROM Estudiante WHERE EstudianteID = 4001;