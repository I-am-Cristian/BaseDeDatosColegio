--Disparadores OK

--- Inserta una calificación cuya evaluación fue hace 15 días
INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (TRUNC(SYSDATE) - 15, 1, 1, XMLType('<opinion>Muy bien</opinion>'));

--- Inserta una calificación cuya evaluación fue hace 2 días
--- (Para probar el UPDATE justo el día correcto)
INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (TRUNC(SYSDATE) - 2, 2, 2, XMLType('<opinion>Inicial</opinion>'));

--- Modifica la calificación exactamente 2 días después de la evaluación
UPDATE Calificacion
SET Opinion = XMLType('<opinion>Actualizado correctamente</opinion>')
WHERE Profesor = 2 AND Asignatura = 2;
