---TuplasOK
--- Usuarios adicionales
INSERT INTO Usuario VALUES (
    4, 'Natalia Herrera', DATE '2022-11-01', NULL,
    '25 años en gestión educativa y planificación institucional'
);

INSERT INTO Usuario VALUES (
    5, 'Iván Ramírez', DATE '2023-01-10', 'ivan.ramirez@escuela.com',
    'Experiencia en docencia y coordinación'
);

--- Nueva Asignatura y Salón
INSERT INTO Asignatura VALUES (11, 'Historia');

INSERT INTO Salon VALUES (101, 102, 11);

--- Nuevo Grado relacionado al nuevo salón
INSERT INTO Grado VALUES (201, 'B1', 101);

--- Nuevo Acudiente
INSERT INTO Acudiente VALUES (301, 'Luis Gómez', 'luis.gomez@correo.com');

--- Estudiante válido
INSERT INTO Estudiante VALUES (
    501, 40054321, 'Maria Forero', DATE '2005-07-04', 'Calle 116 #50A-64', 3135283888,
    'maria.forero@correo.com', 201, 301, 11
);

--- Documento válido relacionado con el estudiante
INSERT INTO Documentos VALUES (
    40054321, 'CC', 1098765432, DATE '2009-01-15', 'Cali', 501
);

--- Profesor con contrato válido y usuario existente
INSERT INTO Profesor VALUES (
    'Ciencias Sociales y Políticas', 'DF', 4
);

--- Calificación con profesor, asignatura y fecha válidos
INSERT INTO Calificacion (
    FechaEvaluacion, Profesor, Asignatura, Opinion
)
VALUES (
    DATE '2024-03-25', 4, 11, XMLType('<opinion>Excelente participación</opinion>')
);

--- Personal administrativo con cargo válido
INSERT INTO PersonalAdministrativo VALUES (
    'Secretarias', 5
);



--- consultas después de cada inserción para validar que realmente se insertó la información.

--- Usuario 4
SELECT * FROM Usuario WHERE UsuarioID = 4;

--- Usuario 5
SELECT * FROM Usuario WHERE UsuarioID = 5;

--- Asignatura 11
SELECT * FROM Asignatura WHERE AsignaturaID = 11;

--- Salón 101
SELECT * FROM Salon WHERE SalonID = 101;

--- Grado 201
SELECT * FROM Grado WHERE GradoID = 201;

--- Acudiente 301
SELECT * FROM Acudiente WHERE Cedula = 301;

--- Estudiante 501
SELECT * FROM Estudiante WHERE EstudianteID = 501;

--- Documento 40054321 (para estudiante 501)
SELECT * FROM Documentos WHERE DocumentoID = 40054321;

--- Profesor (Usuario 4)
SELECT * FROM Profesor WHERE Usuario = 4;

--- Calificación del profesor 4 en asignatura 11
SELECT * FROM Calificacion WHERE Profesor = 4 AND Asignatura = 11;

--- Personal administrativo (Usuario 5)
SELECT * FROM PersonalAdministrativo WHERE Usuario = 5;
