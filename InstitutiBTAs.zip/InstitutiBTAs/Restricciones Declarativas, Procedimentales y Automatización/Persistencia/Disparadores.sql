--- Disparadores
--- Disparador para insertar calificaciones (solo después de 10 días de la evaluación)

CREATE OR REPLACE TRIGGER trg_validar_fecha_insert
BEFORE INSERT ON Calificacion
FOR EACH ROW
BEGIN
  IF TRUNC(SYSDATE) - TRUNC(:NEW.FechaEvaluacion) < 10 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Solo se pueden adicionar calificaciones después de 10 días de la evaluación.');
  END IF;
END;
/


--- Disparador para modificar calificaciones (solo exactamente 2 días después de la evaluación)

CREATE OR REPLACE TRIGGER trg_validar_fecha_update
BEFORE UPDATE ON Calificacion
FOR EACH ROW
BEGIN
  IF TRUNC(SYSDATE) != TRUNC(:OLD.FechaEvaluacion + 2) THEN
    RAISE_APPLICATION_ERROR(-20002, 'Solo se puede modificar la calificación exactamente 2 días después de la evaluación.');
  END IF;
END;
/


