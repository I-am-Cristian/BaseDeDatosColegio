--- Tuplas
--- Restricción de tupla en ESTUDIANTE:
--- Si el correo está informado, el teléfono también debe estar (no puede ser NULL).
ALTER TABLE Estudiante
ADD CONSTRAINT chk_estudiante_correo_telefono
CHECK (
    CorreoElectronico IS NULL OR Telefono IS NOT NULL
);

--- Restricción de tupla en DOCUMENTOS:
--- Si el tipo de documento es 'TI', el número debe tener exactamente 10 dígitos.
ALTER TABLE Documentos
ADD CONSTRAINT chk_documento_ti_numero
CHECK (
    Tipo != 'TI' OR LENGTH(TO_CHAR(Numero)) = 10
);

--- Restricción de tupla en USUARIO:
--- Si el correo está informado, debe ser del dominio institucional @escuela.com
ALTER TABLE Usuario
ADD CONSTRAINT chk_usuario_correo_dominio
CHECK (
    CorreoElectronico IS NULL OR REGEXP_LIKE(CorreoElectronico, '^[A-Za-z0-9._%+-]+@escuela\.com$')
);

