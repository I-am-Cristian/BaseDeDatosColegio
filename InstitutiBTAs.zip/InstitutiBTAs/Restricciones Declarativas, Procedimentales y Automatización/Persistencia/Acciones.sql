--- Acciones De Referencia

--- DROP FKs que se modificarán para permitir acciones referenciales
ALTER TABLE Calificacion DROP CONSTRAINT fk_cal_asignatura;
ALTER TABLE Calificacion DROP CONSTRAINT fk_cal_profesor;
ALTER TABLE Documentos DROP CONSTRAINT fk_documento_estudiante;
ALTER TABLE PersonalAdministrativo DROP CONSTRAINT fk_pa_usuario;

--- Crear nuevamente FKs con ON DELETE CASCADE

--- Regla: Si se elimina una asignatura, también deben eliminarse automáticamente las calificaciones asociadas a ella.
ALTER TABLE Calificacion
ADD CONSTRAINT fk_calif_asignatura
FOREIGN KEY (Asignatura)
REFERENCES Asignatura(AsignaturaID)
ON DELETE CASCADE;

--- Regla: Si se elimina un profesor, también deben eliminarse automáticamente todas las calificaciones que él haya emitido.
ALTER TABLE Calificacion
ADD CONSTRAINT fk_calif_profesor
FOREIGN KEY (Profesor)
REFERENCES Profesor(Usuario)
ON DELETE CASCADE;

--- Regla: Si un estudiante es eliminado del sistema, sus documentos asociados también deben eliminarse.
ALTER TABLE Documentos
ADD CONSTRAINT fk_doc_estudiante
FOREIGN KEY (Estudiante)
REFERENCES Estudiante(EstudianteID)
ON DELETE CASCADE;

--- Regla: Si se elimina el usuario que representa al personal administrativo, su rol administrativo también debe ser eliminado automáticamente.
ALTER TABLE PersonalAdministrativo
ADD CONSTRAINT fk_admin_usuario
FOREIGN KEY (Usuario)
REFERENCES Usuario(UsuarioID)
ON DELETE CASCADE;

