--XDisparadores

-- Eliminar el disparador que valida inserciones

DROP TRIGGER trg_validar_fecha_insert;
/

-- Eliminar el disparador que valida actualizaciones

DROP TRIGGER trg_validar_fecha_update;
/