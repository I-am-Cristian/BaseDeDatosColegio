SELECT * FROM Usuario
WHERE Nombre = 'Carlos Díaz';

SELECT * FROM vista_estudiantes_grado
WHERE NombreGrado = 'Quinto';

SELECT * FROM vista_profesores
WHERE Especializacion = 'Matemáticas';

SELECT * FROM vista_calificaciones
WHERE NombreAsignatura = 'Matemáticas';

