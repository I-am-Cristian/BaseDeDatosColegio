-- Eliminar vistas
DROP VIEW vista_estudiantes_grado;
DROP VIEW vista_profesores;
DROP VIEW vista_calificaciones;

-- Eliminar índices
DROP INDEX idx_usuario_nombre;
DROP INDEX idx_estudiante_grado;
DROP INDEX idx_estudiante_acudiente;
DROP INDEX idx_estudiante_asignatura;
DROP INDEX idx_profesor_usuario;
DROP INDEX idx_calificacion_profesor_asignatura;
