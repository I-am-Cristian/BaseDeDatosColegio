-- Índice sobre el nombre del usuario (acelera búsquedas por nombre)
CREATE INDEX idx_usuario_nombre ON Usuario (Nombre ASC);

-- Índice para facilitar la búsqueda por grado del estudiante
CREATE INDEX idx_estudiante_grado ON Estudiante (Grado ASC);

-- Índice para búsquedas rápidas por acudiente del estudiante
CREATE INDEX idx_estudiante_acudiente ON Estudiante (Acudiente ASC);

-- Índice para búsquedas por asignatura de estudiante
CREATE INDEX idx_estudiante_asignatura ON Estudiante (Asignatura ASC);

-- Índice para búsqueda por usuario en tabla Profesor
CREATE INDEX idx_profesor_usuario ON Profesor (Usuario ASC);

-- Índice compuesto para búsqueda por profesor y asignatura en Calificación
CREATE INDEX idx_calificacion_profesor_asignatura ON Calificacion (Profesor ASC, Asignatura ASC);