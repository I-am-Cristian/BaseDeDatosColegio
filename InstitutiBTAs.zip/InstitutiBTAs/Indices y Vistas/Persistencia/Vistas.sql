-- Vista que muestra nombre del estudiante, grado y número de salón
CREATE VIEW vista_estudiantes_grado AS
SELECT e.Nombre AS NombreEstudiante, g.NombreGrado, s.NumeroSalon
FROM Estudiante e
JOIN Grado g ON e.Grado = g.GradoID
JOIN Salon s ON g.Salon = s.SalonID;

-- Vista que relaciona profesores con sus datos de usuario
CREATE VIEW vista_profesores AS
SELECT u.Nombre AS NombreProfesor, p.Especializacion, u.CorreoElectronico
FROM Profesor p
JOIN Usuario u ON p.Usuario = u.UsuarioID;

-- Vista que muestra calificaciones con asignatura y profesor
CREATE VIEW vista_calificaciones AS
SELECT a.NombreAsignatura, c.FechaEvaluacion, u.Nombre AS NombreProfesor, c.Opinion
FROM Calificacion c
JOIN Asignatura a ON c.Asignatura = a.AsignaturaID
JOIN Profesor p ON c.Profesor = p.Usuario
JOIN Usuario u ON p.Usuario = u.UsuarioID;
