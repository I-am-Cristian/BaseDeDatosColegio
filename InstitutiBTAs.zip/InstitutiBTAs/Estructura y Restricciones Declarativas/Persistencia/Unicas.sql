--- Uk's

ALTER TABLE Usuario
ADD CONSTRAINT uk_usuario_correo UNIQUE (CorreoElectronico);

ALTER TABLE Estudiante
ADD CONSTRAINT uk_estudiante_nombre UNIQUE (Nombre);

ALTER TABLE Estudiante
ADD CONSTRAINT uk_estudiante_telefono UNIQUE (Telefono);

ALTER TABLE Estudiante
ADD CONSTRAINT uk_estudiante_correo UNIQUE (CorreoElectronico);

ALTER TABLE Acudiente
ADD CONSTRAINT uk_acudiente_correo UNIQUE (CorreoElectronico);