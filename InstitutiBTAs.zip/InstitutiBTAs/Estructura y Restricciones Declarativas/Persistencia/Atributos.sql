ALTER TABLE PersonalAdministrativo
ADD CONSTRAINT chk_cargo CHECK (Cargo IN ('Recursos Humanos', 'Contadores y finanzas', 'Secretarias'));

ALTER TABLE Documentos
ADD CONSTRAINT chk_tipo CHECK (Tipo IN ('RC', 'TI', 'CC', 'TE', 'PP'));

ALTER TABLE Profesor
ADD CONSTRAINT chk_contrato CHECK (Contrato IN ('IN', 'DF', 'DR'));

ALTER TABLE Usuario
ADD CONSTRAINT chk_correo_usuario CHECK (
    CorreoElectronico IS NULL OR
    REGEXP_LIKE(CorreoElectronico, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

ALTER TABLE Estudiante
ADD CONSTRAINT chk_correo_estudiante CHECK (
    CorreoElectronico IS NULL OR
    REGEXP_LIKE(CorreoElectronico, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

ALTER TABLE Acudiente
ADD CONSTRAINT chk_correo_acudiente CHECK (
    REGEXP_LIKE(CorreoElectronico, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);
