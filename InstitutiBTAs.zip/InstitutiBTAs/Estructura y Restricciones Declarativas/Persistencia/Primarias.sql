--- Pk's

ALTER TABLE Usuario
ADD CONSTRAINT pk_usuario PRIMARY KEY (UsuarioID);

ALTER TABLE PersonalServiciosGenerales
ADD CONSTRAINT pk_psg PRIMARY KEY (Usuario);

ALTER TABLE PersonalAdministrativo
ADD CONSTRAINT pk_personal_administrativo PRIMARY KEY (Usuario);

ALTER TABLE Profesor
ADD CONSTRAINT pk_profesor PRIMARY KEY (Usuario);

ALTER TABLE Estudiante
ADD CONSTRAINT pk_estudiante PRIMARY KEY (EstudianteID);

ALTER TABLE Documentos
ADD CONSTRAINT pk_documento PRIMARY KEY (DocumentoID);

ALTER TABLE Acudiente
ADD CONSTRAINT pk_acudiente PRIMARY KEY (Cedula);

ALTER TABLE Telefonos
ADD CONSTRAINT pk_telefonos PRIMARY KEY (CedulaID, Telefono);

ALTER TABLE Grado
ADD CONSTRAINT pk_grado PRIMARY KEY (GradoID);

ALTER TABLE Salon
ADD CONSTRAINT pk_salon PRIMARY KEY (SalonID);

ALTER TABLE Asignatura
ADD CONSTRAINT pk_asignatura PRIMARY KEY (AsignaturaID);

ALTER TABLE Calificacion
ADD CONSTRAINT pk_calificacion PRIMARY KEY (Profesor, Asignatura);

