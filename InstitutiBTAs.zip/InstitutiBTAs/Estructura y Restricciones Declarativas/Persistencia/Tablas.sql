CREATE TABLE Usuario (
    UsuarioID NUMBER(10, 0) NOT NULL,
    Nombre VARCHAR(20) NOT NULL,
    FechaContrato DATE NOT NULL,
    CorreoElectronico VARCHAR(50),
    ExperienciaLaboral VARCHAR(500) NOT NULL
);

CREATE TABLE PersonalServiciosGenerales (
    Puesto VARCHAR(30) NOT NULL,
    TipoOficio VARCHAR(30) NOT NULL,
    Usuario NUMBER(10, 0) NOT NULL
);

CREATE TABLE PersonalAdministrativo (
    Cargo VARCHAR(20) NOT NULL,
    Usuario NUMBER(10, 0) NOT NULL
);

CREATE TABLE Estudiante (
    EstudianteID NUMBER(10, 0) NOT NULL,
    Documento NUMBER(10, 0) NOT NULL, 
    Nombre VARCHAR(20) NOT NULL,
    FechaNacimiento DATE NOT NULL,
    Direccion VARCHAR(20) NOT NULL,
    Telefono NUMBER(10, 0) NOT NULL,
    CorreoElectronico VARCHAR(50),
    Grado NUMBER(10, 0) NOT NULL,
    Acudiente NUMBER(10, 0) NOT NULL,
    Asignatura NUMBER(10, 0) NOT NULL
);

CREATE TABLE Documentos (
    DocumentoID NUMBER(10, 0) NOT NULL,
    Tipo CHAR(2) NOT NULL,
    Numero NUMBER(20, 0) NOT NULL,
    FechaExpedicion DATE NOT NULL,
    LugarExpedicion VARCHAR(15) NOT NULL,
    Estudiante NUMBER(10, 0) NOT NULL
);

CREATE TABLE Profesor (
    Especializacion VARCHAR(50) NOT NULL,
    Contrato CHAR(2) NOT NULL,
    Usuario NUMBER(10, 0) NOT NULL
);

CREATE TABLE Acudiente (
    Cedula NUMBER(10,0) NOT NULL,
    Nombre VARCHAR(15) NOT NULL,
    CorreoElectronico VARCHAR(50) NOT NULL
);

CREATE TABLE Grado (
    GradoID NUMBER(10, 0) NOT NULL,
    NombreGrado VARCHAR(10) NOT NULL,
    Salon NUMBER(10, 0) NOT NULL
);

CREATE TABLE Salon (
    SalonID NUMBER(10, 0) NOT NULL,
    NumeroSalon NUMBER(3, 0) NOT NULL,
    Asignatura NUMBER(10, 0) NOT NULL
);

CREATE TABLE Asignatura (
    AsignaturaID NUMBER(10, 0) NOT NULL,
    NombreAsignatura VARCHAR(15) NOT NULL
);

CREATE TABLE Calificacion (
    FechaEvaluacion DATE NOT NULL,
    Profesor NUMBER(10, 0) NOT NULL,
    Asignatura NUMBER(10, 0) NOT NULL,
    Opinion XMLType
);

CREATE TABLE Telefonos(
    CedulaID Number(10,0)  NOT NULL,
    telefono NUMBER(10,0) NOT NULL
);

