---Fk's

ALTER TABLE PersonalServiciosGenerales
ADD CONSTRAINT fk_psg_usuario FOREIGN KEY (Usuario) REFERENCES Usuario(UsuarioID);

ALTER TABLE PersonalAdministrativo
ADD CONSTRAINT fk_pa_usuario FOREIGN KEY (Usuario) REFERENCES Usuario(UsuarioID);

ALTER TABLE Profesor
ADD CONSTRAINT fk_profesor_usuario FOREIGN KEY (Usuario) REFERENCES Usuario(UsuarioID);

ALTER TABLE Estudiante
ADD CONSTRAINT fk_estudiante_grado FOREIGN KEY (Grado) REFERENCES Grado(GradoID);

ALTER TABLE Estudiante
ADD CONSTRAINT fk_estudiante_acudiente FOREIGN KEY (Acudiente) REFERENCES Acudiente(Cedula);

ALTER TABLE Telefonos
ADD CONSTRAINT fk_telefonos_acudiente FOREIGN KEY (CedulaID) REFERENCES Acudiente(Cedula);

ALTER TABLE Documentos
ADD CONSTRAINT fk_documento_estudiante FOREIGN KEY (Estudiante) REFERENCES Estudiante(EstudianteID);

ALTER TABLE Estudiante
ADD CONSTRAINT fk_estudiante_asignatura FOREIGN KEY (Asignatura) REFERENCES Asignatura(AsignaturaID);

ALTER TABLE Grado
ADD CONSTRAINT fk_grado_salon FOREIGN KEY (Salon) REFERENCES Salon(SalonID);

ALTER TABLE Salon
ADD CONSTRAINT fk_salon_asignatura FOREIGN KEY (Asignatura) REFERENCES Asignatura(AsignaturaID);

ALTER TABLE Calificacion
ADD CONSTRAINT fk_cal_profesor FOREIGN KEY (Profesor) REFERENCES Profesor(Usuario);

ALTER TABLE Calificacion
ADD CONSTRAINT fk_cal_asignatura FOREIGN KEY (Asignatura) REFERENCES Asignatura(AsignaturaID);

