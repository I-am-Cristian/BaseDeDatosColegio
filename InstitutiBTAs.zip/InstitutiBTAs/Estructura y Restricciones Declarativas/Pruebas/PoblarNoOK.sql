--- PoblarNoOK

--- Usuario: correo inválido (violación CHECK)
INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (10, 'Error User', DATE '2022-01-01', 'correo-invalido', 'Texto');

--- PersonalServiciosGenerales: FK inválida (usuario no existe)
INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Jardinería', 'Exterior', 999);

--- PersonalAdministrativo: valor fuera de los permitidos en CHECK (cargo)
INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Gerente', 10);

--- Profesor: contrato inválido (CHECK)
INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Química', 'XX', 10);

--- Acudiente: correo duplicado (viola UNIQUE)
INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (301, 'Pedro Gómez', 'marta.gomez@correo.com');

--- Grado: clave primaria repetida
INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (200, 'Sexto', 101);  -- GradoID 200 ya existe

--- Salon: asignatura inexistente (violación de FK)
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura)
VALUES (101, 202, 999);

--- Asignatura: nombre demasiado largo (violación del tamaño de columna)
INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (11, 'AsignaturaMuyLargaNombre');

--- Estudiante: nombre duplicado (UNIQUE)
INSERT INTO Estudiante (
    EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono,
    CorreoElectronico, Grado, Acudiente, Asignatura
) VALUES (
    501, 401, 'Julián López', DATE '2009-05-10', 'Cra 20 #45-60', 3209876543,
    'nuevo@correo.com', 200, 300, 10
);

--- Documentos: campo requerido NULL (violación NOT NULL)
INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (401, NULL, 123456789, DATE '2020-01-01', 'Cali', 500);

--- Telefonos: PK duplicada (CedulaID + Telefono ya existe)
INSERT INTO Telefonos (CedulaID, Telefono)
VALUES (300, 3104567890);

--- Calificacion: profesor inexistente (violación de FK)
INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-05-01', 999, 10, XMLType('<opinion>Inexistente</opinion>'));

