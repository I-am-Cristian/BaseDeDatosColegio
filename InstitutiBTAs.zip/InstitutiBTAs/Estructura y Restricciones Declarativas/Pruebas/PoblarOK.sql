--- PoblarOK

-- Usuario 
INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (1, 'Ana Ruiz', DATE '2022-01-10', 'ana.ruiz@correo.com', '5 años en limpieza');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (2, 'Carlos Díaz', DATE '2021-06-01', 'carlos.diaz@correo.com', '3 años en oficina');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (3, 'Luis Pérez', DATE '2020-03-20', 'luis.perez@correo.com', '8 años como profesor');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (4, 'María Torres', DATE '2019-11-05', 'maria.torres@correo.com', '4 años en administración');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (5, 'José Ramírez', DATE '2018-08-22', 'jose.ramirez@correo.com', '10 años como vigilante');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (6, 'Laura Gómez', DATE '2023-02-14', 'laura.gomez@correo.com', '2 años en recursos humanos');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (7, 'Andrés Soto', DATE '2021-05-30', 'andres.soto@correo.com', '6 años como celador');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (8, 'Natalia Herrera', DATE '2020-10-19', 'natalia.herrera@correo.com', '3 años en servicios generales');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (9, 'Julián Morales', DATE '2017-04-13', 'julian.morales@correo.com', '7 años como técnico de sistemas');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (10, 'Paula Mendoza', DATE '2016-06-27', 'paula.mendoza@correo.com', '5 años como auxiliar contable');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (11, 'Camilo Vargas', DATE '2022-07-01', 'camilo.vargas@correo.com', '4 años en soporte técnico');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (12, 'Sara López', DATE '2019-03-18', 'sara.lopez@correo.com', '6 años como profesora de inglés');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (13, 'Héctor Ríos', DATE '2018-12-10', 'hector.rios@correo.com', '8 años como conductor');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (14, 'Manuela Castaño', DATE '2023-01-25', 'manuela.castano@correo.com', '1 año como recepcionista');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (15, 'David Rodríguez', DATE '2020-08-05', 'david.rodriguez@correo.com', '9 años en mantenimiento');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (16, 'Tatiana León', DATE '2022-11-15', 'tatiana.leon@correo.com', '3 años en enfermería');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (17, 'Esteban Parra', DATE '2021-09-09', 'esteban.parra@correo.com', '2 años como bibliotecario');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (18, 'Luisa Gil', DATE '2017-01-20', 'luisa.gil@correo.com', '11 años como docente');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (19, 'Federico Ruiz', DATE '2019-05-02', 'federico.ruiz@correo.com', '5 años en sistemas');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (20, 'Viviana Ocampo', DATE '2016-03-14', 'viviana.ocampo@correo.com', '7 años como secretaria');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (21, 'Martín Suárez', DATE '2018-07-12', 'martin.suarez@correo.com', '6 años como jardinero');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (22, 'Diana Paredes', DATE '2021-10-03', 'diana.paredes@correo.com', '3 años en archivo');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (23, 'Oscar Castillo', DATE '2019-12-29', 'oscar.castillo@correo.com', '10 años como celador');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (24, 'Daniela Rincón', DATE '2022-05-08', 'daniela.rincon@correo.com', '2 años en atención al cliente');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (25, 'Cristian Peña', DATE '2020-09-25', 'cristian.pena@correo.com', '4 años como mensajero');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (26, 'Melissa Bernal', DATE '2023-03-04', 'melissa.bernal@correo.com', '1 año como auxiliar de biblioteca');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (27, 'Álvaro Fuentes', DATE '2017-06-30', 'alvaro.fuentes@correo.com', '12 años como celador nocturno');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (28, 'Juana Cortés', DATE '2018-02-11', 'juana.cortes@correo.com', '6 años en servicios generales');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (29, 'Iván Guerrero', DATE '2021-11-19', 'ivan.guerrero@correo.com', '3 años como asistente técnico');

INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
VALUES (30, 'Mónica Salazar', DATE '2020-04-06', 'monica.salazar@correo.com', '5 años como recepcionista');



-- Personal
INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Aseo', 'Limpieza', 1);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Mantenimiento', 'Electricidad', 5);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Vigilancia', 'Seguridad Nocturna', 7);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Servicios Varios', 'Jardinería', 9);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Aseo', 'Baños y aulas', 13);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Vigilancia', 'Ingreso Principal', 15);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Mantenimiento', 'Fontanería', 21);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Limpieza', 'Áreas comunes', 23);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Jardinería', 'Zonas verdes', 27);

INSERT INTO PersonalServiciosGenerales (Puesto, TipoOficio, Usuario)
VALUES ('Vigilancia', 'Parqueaderos', 28);


INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Contadores y finanzas', 2);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Secretaria académica', 4);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Auxiliar contable', 6);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Coordinador general', 10);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Asistente de rectoría', 12);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Recursos humanos', 14);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Soporte técnico', 16);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Archivo', 20);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Tesorero', 22);

INSERT INTO PersonalAdministrativo (Cargo, Usuario)
VALUES ('Recepción', 30);


INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Matemáticas', 'IN', 3);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Lengua Castellana', 'IN', 8);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Inglés', 'CT', 11);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Ciencias Naturales', 'CT', 17);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Educación Física', 'IN', 18);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Informática', 'CT', 19);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Sociales', 'IN', 24);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Filosofía', 'CT', 25);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Artes Plásticas', 'CT', 26);

INSERT INTO Profesor (Especializacion, Contrato, Usuario)
VALUES ('Religión', 'IN', 29);


-- Asignatura
INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (1, 'Matemáticas');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (2, 'Español');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (3, 'Inglés');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (4, 'Ciencias');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (5, 'Biología');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (6, 'Química');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (7, 'Física');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (8, 'Historia');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (9, 'Geografía');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (10, 'Matemáticas');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (11, 'Religión');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (12, 'Ética');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (13, 'Educación Física');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (14, 'Tecnología');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (15, 'Informática');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (16, 'Filosofía');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (17, 'Literatura');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (18, 'Artes');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (19, 'Música');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (20, 'Francés');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (21, 'Cálculo');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (22, 'Estadística');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (23, 'Algebra');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (24, 'Geometría');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (25, 'Trigonometría');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (26, 'Programación');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (27, 'Robótica');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (28, 'Cívica');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (29, 'Derecho');

INSERT INTO Asignatura (AsignaturaID, NombreAsignatura)
VALUES (30, 'Emprendimiento');


-- Salon
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (100, 101, 10);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (101, 102, 5);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (102, 103, 3);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (103, 104, 7);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (104, 105, 12);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (105, 106, 8);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (106, 107, 15);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (107, 108, 9);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (108, 109, 4);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (109, 110, 2);

INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (110, 111, 6);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (111, 112, 11);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (112, 113, 13);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (113, 114, 16);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (114, 115, 14);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (115, 116, 17);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (116, 117, 1);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (117, 118, 18);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (118, 119, 19);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (119, 120, 20);

INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (120, 121, 1);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (121, 122, 3);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (122, 123, 6);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (123, 124, 2);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (124, 125, 5);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (125, 126, 7);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (126, 127, 9);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (127, 128, 8);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (128, 129, 11);
INSERT INTO Salon (SalonID, NumeroSalon, Asignatura) VALUES (129, 130, 4);


-- Grado
INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (200, 'Quinto', 100);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (201, 'Primero', 101);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (202, 'Segundo', 102);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (203, 'Tercero', 103);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (204, 'Cuarto', 104);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (205, 'Quinto', 105);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (206, 'Sexto', 106);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (207, 'Séptimo', 107);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (208, 'Octavo', 108);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (209, 'Noveno', 109);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (210, 'Décimo', 110);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (211, 'Undécimo', 111);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (212, 'Primero', 112);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (213, 'Segundo', 113);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (214, 'Tercero', 114);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (215, 'Cuarto', 115);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (216, 'Quinto', 116);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (217, 'Sexto', 117);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (218, 'Séptimo', 118);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (219, 'Octavo', 119);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (220, 'Noveno', 120);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (221, 'Décimo', 121);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (222, 'Undécimo', 122);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (223, 'Primero', 123);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (224, 'Segundo', 124);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (225, 'Tercero', 125);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (226, 'Cuarto', 126);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (227, 'Quinto', 127);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (228, 'Sexto', 128);

INSERT INTO Grado (GradoID, NombreGrado, Salon)
VALUES (229, 'Séptimo', 129);


-- Acudiente
INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (300, 'Marta Gómez', 'marta.gomez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (301, 'Carlos Álvarez', 'carlos.alvarez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (302, 'Lucía Rodríguez', 'lucia.rodriguez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (303, 'Jorge Méndez', 'jorge.mendez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (304, 'Sandra López', 'sandra.lopez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (305, 'Diana Torres', 'diana.torres@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (306, 'Luis Herrera', 'luis.herrera@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (307, 'Patricia Ramírez', 'patricia.ramirez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (308, 'Fernando Díaz', 'fernando.diaz@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (309, 'Paola Castillo', 'paola.castillo@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (310, 'Esteban Ríos', 'esteban.rios@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (311, 'Laura Jiménez', 'laura.jimenez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (312, 'Julián Vargas', 'julian.vargas@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (313, 'Angela Peña', 'angela.pena@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (314, 'Oscar Suárez', 'oscar.suarez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (315, 'Gloria Moreno', 'gloria.moreno@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (316, 'Andrés Ruiz', 'andres.ruiz@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (317, 'Beatriz Cortés', 'beatriz.cortes@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (318, 'Iván León', 'ivan.leon@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (319, 'Tatiana Gil', 'tatiana.gil@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (320, 'Camilo Soto', 'camilo.soto@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (321, 'Silvia Paredes', 'silvia.paredes@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (322, 'Jhon Martínez', 'jhon.martinez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (323, 'Claudia Romero', 'claudia.romero@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (324, 'Mauricio Gómez', 'mauricio.gomez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (325, 'Natalia Benítez', 'natalia.benitez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (326, 'Ricardo Parra', 'ricardo.parra@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (327, 'Luisa Velásquez', 'luisa.velasquez@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (328, 'Diego Salazar', 'diego.salazar@correo.com');

INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
VALUES (329, 'Monica Estrada', 'monica.estrada@correo.com');


-- Estudiante
INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (500, 400, 'Julián López', DATE '2008-06-12', 'Cra 10 #15-20', 3201234567,'julian.lopez@correo.com', 200, 300, 10);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (501, 401, 'Sofía Ríos', DATE '2009-03-25', 'Cll 8 #24-11', 3104567890, 'sofia.rios@correo.com', 201, 301, 11);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (502, 402, 'Mateo Martínez', DATE '2007-11-03', 'Av 3 #9-40', 3137894561, 'mateo.martinez@correo.com', 202, 302, 12);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (503, 403, 'Isabella Torres', DATE '2008-08-14', 'Cll 14 #33-10', 3124567890, 'isabella.torres@correo.com', 203, 303, 13);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (504, 404, 'Samuel Ramírez', DATE '2009-12-01', 'Cra 20 #45-21', 3111234567, 'samuel.ramirez@correo.com', 204, 304, 14);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (505, 405, 'Valentina Ruiz', DATE '2007-07-30', 'Cll 5 #17-25', 3101112233, 'valentina.ruiz@correo.com', 205, 305, 15);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (506, 406, 'Tomás Moreno', DATE '2008-04-18', 'Av 6 #22-45', 3209998888, 'tomas.moreno@correo.com', 206, 306, 16);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (507, 407, 'Emilia Castaño', DATE '2009-05-05', 'Cll 2 #10-30', 3149876543, 'emilia.castano@correo.com', 207, 307, 17);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (508, 408, 'Emmanuel Vargas', DATE '2007-09-19', 'Cra 9 #19-12', 3112345678, 'emmanuel.vargas@correo.com', 208, 308, 18);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (509, 409, 'Antonella Díaz', DATE '2008-10-28', 'Cll 16 #40-31', 3150001111, 'antonella.diaz@correo.com', 209, 309, 19);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (510, 410, 'Martín Pardo', DATE '2009-02-02', 'Av 5 #12-08', 3187776655, 'martin.pardo@correo.com', 210, 310, 20);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (511, 411, 'Laura Peña', DATE '2007-01-11', 'Cll 3 #9-40', 3108765432, 'laura.pena@correo.com', 211, 311, 21);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (512, 412, 'Luciana Gaitán', DATE '2008-03-16', 'Cra 7 #13-28', 3132223344, 'luciana.gaitan@correo.com', 212, 312, 22);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (513, 413, 'Benjamín Silva', DATE '2009-07-09', 'Cll 19 #25-09', 3194445566, 'benjamin.silva@correo.com', 213, 313, 23);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (514, 414, 'Regina Cortés', DATE '2007-08-13', 'Cra 11 #21-11', 3140009999, 'regina.cortes@correo.com', 214, 314, 24);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (515, 415, 'Simón Beltrán', DATE '2008-01-22', 'Cll 6 #16-22', 3121234567, 'simon.beltran@correo.com', 215, 315, 25);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (516, 416, 'Catalina Mejía', DATE '2009-11-04', 'Av 1 #7-44', 3152345678, 'catalina.mejia@correo.com', 216, 316, 26);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (517, 417, 'Maximiliano Ibáñez', DATE '2007-06-26', 'Cra 5 #8-14', 3199876543, 'max.ibanez@correo.com', 217, 317, 27);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (518, 418, 'Gabriela Navarro', DATE '2008-02-18', 'Cll 13 #26-33', 3105556666, 'gabriela.navarro@correo.com', 218, 318, 28);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (519, 419, 'León Acosta', DATE '2009-09-01', 'Av 2 #18-29', 3171237890, 'leon.acosta@correo.com', 219, 319, 29);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (520, 420, 'Camila Sánchez', DATE '2007-10-05', 'Cra 12 #30-11', 3145551234, 'camila.sanchez@correo.com', 220, 320, 30);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (521, 421, 'Thiago León', DATE '2008-06-06', 'Cll 7 #15-07', 3114567890, 'thiago.leon@correo.com', 221, 321, 31);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (522, 422, 'Renata Medina', DATE '2009-01-20', 'Av 8 #14-10', 3123456789, 'renata.medina@correo.com', 222, 322, 32);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (523, 423, 'Jerónimo Andrade', DATE '2007-04-04', 'Cra 16 #17-25', 3137896541, 'jeronimo.andrade@correo.com', 223, 323, 33);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (524, 424, 'Salomé Guerrero', DATE '2008-12-10', 'Cll 12 #22-09', 3164443332, 'salome.guerrero@correo.com', 224, 324, 34);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (525, 425, 'Diego Castro', DATE '2009-08-03', 'Av 9 #10-40', 3100002222, 'diego.castro@correo.com', 225, 325, 35);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (526, 426, 'Zoe Cabrera', DATE '2007-03-07', 'Cra 2 #18-88', 3129876543, 'zoe.cabrera@correo.com', 226, 326, 36);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (527, 427, 'Emilio Rangel', DATE '2008-05-25', 'Cll 11 #29-99', 3191122334, 'emilio.rangel@correo.com', 227, 327, 37);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (528, 428, 'Alma Valencia', DATE '2009-06-08', 'Av 7 #13-17', 3185566778, 'alma.valencia@correo.com', 228, 328, 38);

INSERT INTO Estudiante (EstudianteID, Documento, Nombre, FechaNacimiento, Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura) 
VALUES (529, 429, 'Santiago Hoyos', DATE '2007-09-27', 'Cra 1 #11-45', 3119998888, 'santiago.hoyos@correo.com', 229, 329, 39);


-- Documentos
INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (400, 'TI', 1056874123, DATE '2010-04-20', 'Bogotá', 500);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (401, 'TI', 1045823991, DATE '2011-06-15', 'Medellín', 501);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (402, 'TI', 1074512388, DATE '2012-03-30', 'Cali', 502);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (403, 'TI', 1087765412, DATE '2009-09-10', 'Barranquilla', 503);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (404, 'TI', 1093847201, DATE '2010-01-22', 'Cartagena', 504);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (405, 'TI', 1038741596, DATE '2011-12-05', 'Cúcuta', 505);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (406, 'TI', 1065234910, DATE '2010-07-18', 'Ibagué', 506);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (407, 'TI', 1071948752, DATE '2013-04-01', 'Pereira', 507);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (408, 'TI', 1054172894, DATE '2008-11-27', 'Manizales', 508);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (409, 'TI', 1049812374, DATE '2009-08-16', 'Neiva', 509);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (410, 'TI', 1067239845, DATE '2012-02-03', 'Tunja', 510);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (411, 'TI', 1085412739, DATE '2010-09-09', 'Montería', 511);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (412, 'TI', 1071324587, DATE '2013-01-15', 'Santa Marta', 512);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (413, 'TI', 1043826591, DATE '2008-10-21', 'Villavicencio', 513);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (414, 'TI', 1098741236, DATE '2011-05-14', 'Popayán', 514);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (415, 'TI', 1039218475, DATE '2010-06-30', 'Armenia', 515);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (416, 'TI', 1081432964, DATE '2009-12-19', 'Sincelejo', 516);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (417, 'TI', 1056219873, DATE '2012-07-03', 'Riohacha', 517);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (418, 'TI', 1048791326, DATE '2011-04-17', 'Florencia', 518);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (419, 'TI', 1079823156, DATE '2013-03-11', 'Yopal', 519);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (420, 'TI', 1084932176, DATE '2010-08-25', 'Quibdó', 520);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (421, 'TI', 1053762984, DATE '2012-06-06', 'Mocoa', 521);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (422, 'TI', 1062198374, DATE '2011-09-13', 'San José', 522);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (423, 'TI', 1097412365, DATE '2009-02-01', 'Inírida', 523);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (424, 'TI', 1076543219, DATE '2010-10-12', 'Leticia', 524);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (425, 'TI', 1058942173, DATE '2008-12-29', 'Puerto Carreño', 525);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (426, 'TI', 1063478910, DATE '2011-11-04', 'Bogotá', 526);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (427, 'TI', 1092384756, DATE '2012-01-08', 'Medellín', 527);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (428, 'TI', 1083217465, DATE '2013-05-26', 'Cali', 528);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (429, 'TI', 1047192836, DATE '2009-06-20', 'Barranquilla', 529);

INSERT INTO Documentos (DocumentoID, Tipo, Numero, FechaExpedicion, LugarExpedicion, Estudiante)
VALUES (430, 'TI', 1074928137, DATE '2010-03-11', 'Cartagena', 530);


-- Telefonos
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (300, 3104567890);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (301, 3112345678);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (302, 3123456789);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (303, 3139876543);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (304, 3148765432);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (305, 3157654321);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (306, 3166543210);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (307, 3175432109);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (308, 3184321098);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (309, 3193210987);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (310, 3102109876);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (311, 3111098765);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (312, 3129988776);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (313, 3138877665);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (314, 3147766554);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (315, 3156655443);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (316, 3165544332);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (317, 3174433221);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (318, 3183322110);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (319, 3192211009);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (320, 3101122334);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (321, 3112233445);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (322, 3123344556);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (323, 3134455667);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (324, 3145566778);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (325, 3156677889);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (326, 3167788990);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (327, 3178899001);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (328, 3189900112);
INSERT INTO Telefonos (CedulaID, Telefono) VALUES (329, 3191011123);


-- Calificacion
INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-20', 3, 10, XMLType('<opinion>Buen desempeño</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-15', 5, 12, XMLType('<opinion>Participativo en clase</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-01-25', 7, 9, XMLType('<opinion>Necesita mejorar en matemáticas</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-05', 4, 11, XMLType('<opinion>Excelente presentación de proyecto</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-10', 6, 8, XMLType('<opinion>Falta a clase con frecuencia</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-22', 2, 10, XMLType('<opinion>Muy buen desempeño en grupo</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-10', 8, 7, XMLType('<opinion>Entiende los conceptos clave</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-30', 1, 6, XMLType('<opinion>No entrega tareas a tiempo</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-01-28', 9, 10, XMLType('<opinion>Excelente participación</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-15', 10, 5, XMLType('<opinion>Debe practicar más lectura</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-05', 3, 11, XMLType('<opinion>Trabajo en equipo destacado</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-12', 4, 9, XMLType('<opinion>Promedio sobresaliente</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-01-30', 5, 12, XMLType('<opinion>Debe mejorar ortografía</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-17', 6, 6, XMLType('<opinion>Rinde muy bien en ciencias</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-22', 2, 10, XMLType('<opinion>Actitud positiva</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-03', 7, 8, XMLType('<opinion>Le cuesta concentrarse</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-01-18', 8, 9, XMLType('<opinion>Participa activamente</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-18', 9, 7, XMLType('<opinion>Muy creativo</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-08', 10, 11, XMLType('<opinion>Desempeño aceptable</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-12', 1, 6, XMLType('<opinion>Requiere más disciplina</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-07', 3, 5, XMLType('<opinion>Buen trabajo en exposición</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-27', 2, 12, XMLType('<opinion>Responsable y puntual</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-01-11', 4, 8, XMLType('<opinion>Debe estudiar más en casa</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-25', 6, 9, XMLType('<opinion>Buen liderazgo</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-11', 7, 7, XMLType('<opinion>Hace preguntas interesantes</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-01-14', 9, 10, XMLType('<opinion>Actitud colaborativa</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-08', 5, 11, XMLType('<opinion>Presentó avance destacado</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-03-01', 10, 6, XMLType('<opinion>Debe reforzar matemáticas</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-02-18', 8, 8, XMLType('<opinion>Esfuerzo constante</opinion>'));

INSERT INTO Calificacion (FechaEvaluacion, Profesor, Asignatura, Opinion)
VALUES (DATE '2024-04-20', 1, 9, XMLType('<opinion>Muy participativo en debates</opinion>'));

