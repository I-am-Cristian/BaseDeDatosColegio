--- XPoblar

DELETE FROM Calificacion;
DELETE FROM Documentos;
DELETE FROM Telefonos;
DELETE FROM Estudiante;
DELETE FROM Acudiente;
DELETE FROM Grado;
DELETE FROM Salon;
DELETE FROM Asignatura;
DELETE FROM Profesor;
DELETE FROM PersonalAdministrativo;
DELETE FROM PersonalServiciosGenerales;
DELETE FROM Usuario;