--PKG_CALIFICACION
CREATE OR REPLACE PACKAGE PKG_CALIFICACION 
IS
PROCEDURE AdicionarCalificaciones(Asignatura IN VARCHAR2,Profesor IN VARCHAR2,FechaEvaluacion IN DATE,Opinion IN XMLTYPE);
PROCEDURE ConsultarCalificaciones(NombreAsignatura IN VARCHAR2, EstudianteID IN VARCHAR2, Nombre IN VARCHAR2);
PROCEDURE ModificarCalificaciones(NombreAsignatura IN VARCHAR2, FechaEvaluacion IN DATE);
PROCEDURE EliminarCalificaciones(AsignaturaId IN VARCHAR2,ProfesorId IN VARCHAR2 );
END;
/

--PKG_ESTUDIANTE
CREATE OR REPLACE PACKAGE PKG_ESTUDIANTE 
IS
PROCEDURE AdicionarEstudiante( EstudianteID IN VARCHAR2, FechaNacimiento IN DATE, Direccion IN VARCHAR2, Telefono IN VARCHAR2, CorreoElectronico IN VARCHAR2);
PROCEDURE ConsultarEstudiante(EstudianteID IN VARCHAR2);
PROCEDURE EliminarEstudiante(EstidianteID IN VARCHAR2, Nombre IN VARCHAR2);
END ;
/

--PKG_PROFESOR
CREATE OR REPLACE PACKAGE PKG_PROFESOR 
IS
PROCEDURE AdicionarProfesor(Usuario IN VARCHAR2, Especializacion IN VARCHAR2, Contrato IN CHAR, Nombre IN VARCHAR2, FechaContrato IN DATE, CorreoElectronico IN VARCHAR2, ExperienciaLaboral IN VARCHAR2 );
PROCEDURE ModificarProfesor( Usuario IN VARCHAR2, Nombre IN VARCHAR2);
PROCEDURE ConsultarProfesor( Nombre IN VARCHAR2 );
END;
/

--PKG_ACUDIENTE
CREATE OR REPLACE PACKAGE PKG_ACUDIENTE 
IS
PROCEDURE AdicionarAcudiente( Cedula IN VARCHAR2, Nombre IN VARCHAR2, CorreoElectronico IN VARCHAR2);
PROCEDURE EliminarAcudiente( Cedula IN VARCHAR2);
PROCEDURE ModificarAcudiente(Cedula IN VARCHAR2, Nombre IN VARCHAR2);
PROCEDURE ConsultarAcudiente( Nombre IN VARCHAR2);
END;
/

--PKG_PERSONAL_ADMINISTRATIVO
CREATE OR REPLACE PACKAGE PKG_PERSONAL_ADMINISTRATIVO 
IS
PROCEDURE AdicionarPersonalAdministrativo( Usuario IN VARCHAR2, Cargo IN VARCHAR2, Nombre IN VARCHAR2, FechaContrato IN DATE,CorreoElectronico IN VARCHAR2, ExperienciaLaboral IN VARCHAR2);
PROCEDURE ModificarPersonalAdministrativo(Usuario IN VARCHAR2,Nombre IN VARCHAR2);
PROCEDURE EliminarPersonalAdministrativo(Usuario IN VARCHAR2,Nombre IN VARCHAR2,Cargo IN VARCHAR2);
PROCEDURE ConsultarPersonalAdministrativo(Nombre IN VARCHAR2);
END ;
/




