--(PACKTAGE BODY) CALIFICACION:

CREATE OR REPLACE PACKAGE BODY PKG_CALIFICACION IS

    PROCEDURE AdicionarCalificaciones(
        Asignatura IN VARCHAR2,
        Profesor IN VARCHAR2,
        FechaEvaluacion IN DATE,
        Opinion IN XMLTYPE
    ) IS
    BEGIN
        INSERT INTO Calificacion (Asignatura, Profesor, FechaEvaluacion, Opinion)
        VALUES (TO_NUMBER(Asignatura), TO_NUMBER(Profesor), FechaEvaluacion, Opinion);
    END AdicionarCalificaciones;


    PROCEDURE ConsultarCalificaciones(
        NombreAsignatura IN VARCHAR2,
        EstudianteID IN VARCHAR2,
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        FOR cali IN (
            SELECT c.FechaEvaluacion, a.NombreAsignatura, c.Opinion
            FROM Calificacion c
            JOIN Asignatura a ON c.Asignatura = a.AsignaturaID
            JOIN Estudiante e ON e.Asignatura = a.AsignaturaID
            WHERE a.NombreAsignatura = NombreAsignatura
              AND e.EstudianteID = TO_NUMBER(EstudianteID)
              AND e.Nombre = Nombre
        ) LOOP
            DBMS_OUTPUT.PUT_LINE('Fecha: ' || cali.FechaEvaluacion);
            DBMS_OUTPUT.PUT_LINE('Asignatura: ' || cali.NombreAsignatura);
            DBMS_OUTPUT.PUT_LINE('Opinion: ' || cali.Opinion.getClobVal());
        END LOOP;
    END ConsultarCalificaciones;


    PROCEDURE ModificarCalificaciones(
        NombreAsignatura IN VARCHAR2,
        FechaEvaluacion IN DATE
    ) IS
    BEGIN
        UPDATE Calificacion c
        SET Opinion = XMLTYPE('<actualizado>Nueva opinión</actualizado>')
        WHERE c.Asignatura IN (
            SELECT AsignaturaID FROM Asignatura WHERE NombreAsignatura = NombreAsignatura
        )
        AND c.FechaEvaluacion = FechaEvaluacion;
    END ModificarCalificaciones;


    PROCEDURE EliminarCalificaciones(
        AsignaturaId IN VARCHAR2,
        ProfesorId IN VARCHAR2
    ) IS
    BEGIN
        DELETE FROM Calificacion
        WHERE Asignatura = TO_NUMBER(AsignaturaId)
          AND Profesor = TO_NUMBER(ProfesorId);
    END EliminarCalificaciones;

END PKG_CALIFICACION;
/

--(PACKTAGE BODY) ESTUDIANTE:
CREATE OR REPLACE PACKAGE BODY PKG_ESTUDIANTE IS

    PROCEDURE AdicionarEstudiante(
        EstudianteID IN VARCHAR2,
        FechaNacimiento IN DATE,
        Direccion IN VARCHAR2,
        Telefono IN VARCHAR2,
        CorreoElectronico IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Estudiante (
            EstudianteID, Documento, Nombre, FechaNacimiento,
            Direccion, Telefono, CorreoElectronico, Grado, Acudiente, Asignatura
        ) VALUES (
            TO_NUMBER(EstudianteID), 
            0, -- Documento dummy
            'NoAsignado', -- Nombre dummy
            FechaNacimiento,
            Direccion,
            TO_NUMBER(Telefono),
            CorreoElectronico,
            0, -- Grado dummy
            0, -- Acudiente dummy
            0  -- Asignatura dummy
        );
    END AdicionarEstudiante;


    PROCEDURE ConsultarEstudiante(
        EstudianteID IN VARCHAR2
    ) IS
        v_nombre VARCHAR2(20);
        v_direccion VARCHAR2(20);
        v_telefono NUMBER;
        v_correo VARCHAR2(50);
        v_fnac DATE;
    BEGIN
        SELECT Nombre, Direccion, Telefono, CorreoElectronico, FechaNacimiento
        INTO v_nombre, v_direccion, v_telefono, v_correo, v_fnac
        FROM Estudiante
        WHERE EstudianteID = TO_NUMBER(EstudianteID);

        DBMS_OUTPUT.PUT_LINE('Nombre: ' || v_nombre);
        DBMS_OUTPUT.PUT_LINE('Fecha Nacimiento: ' || TO_CHAR(v_fnac, 'YYYY-MM-DD'));
        DBMS_OUTPUT.PUT_LINE('Dirección: ' || v_direccion);
        DBMS_OUTPUT.PUT_LINE('Teléfono: ' || v_telefono);
        DBMS_OUTPUT.PUT_LINE('Correo: ' || v_correo);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Estudiante no encontrado.');
    END ConsultarEstudiante;


    PROCEDURE EliminarEstudiante(
        EstidianteID IN VARCHAR2,
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        DELETE FROM Estudiante
        WHERE EstudianteID = TO_NUMBER(EstidianteID)
          AND Nombre = Nombre;
    END EliminarEstudiante;

END PKG_ESTUDIANTE;
/

--(PACKTAGE BODY) PROFESOR:
CREATE OR REPLACE PACKAGE BODY PKG_PROFESOR IS

    PROCEDURE AdicionarProfesor(
        Usuario IN VARCHAR2,
        Especializacion IN VARCHAR2,
        Contrato IN CHAR,
        Nombre IN VARCHAR2,
        FechaContrato IN DATE,
        CorreoElectronico IN VARCHAR2,
        ExperienciaLaboral IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Usuario (
            UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral
        ) VALUES (
            TO_NUMBER(Usuario), Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral
        );

        INSERT INTO Profesor (
            Usuario, Especializacion, Contrato
        ) VALUES (
            TO_NUMBER(Usuario), Especializacion, Contrato
        );
    END AdicionarProfesor;


    PROCEDURE ModificarProfesor(
        Usuario IN VARCHAR2,
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Usuario
        SET Nombre = Nombre
        WHERE UsuarioID = TO_NUMBER(Usuario);
    END ModificarProfesor;


    PROCEDURE ConsultarProfesor(
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        FOR prof IN (
            SELECT u.UsuarioID, u.Nombre, u.FechaContrato, u.CorreoElectronico, 
                   u.ExperienciaLaboral, p.Especializacion, p.Contrato
            FROM Usuario u
            JOIN Profesor p ON u.UsuarioID = p.Usuario
            WHERE UPPER(u.Nombre) = UPPER(Nombre)
        ) LOOP
            DBMS_OUTPUT.PUT_LINE('UsuarioID: ' || prof.UsuarioID);
            DBMS_OUTPUT.PUT_LINE('Nombre: ' || prof.Nombre);
            DBMS_OUTPUT.PUT_LINE('Fecha Contrato: ' || prof.FechaContrato);
            DBMS_OUTPUT.PUT_LINE('Correo: ' || prof.CorreoElectronico);
            DBMS_OUTPUT.PUT_LINE('Experiencia: ' || prof.ExperienciaLaboral);
            DBMS_OUTPUT.PUT_LINE('Especialización: ' || prof.Especializacion);
            DBMS_OUTPUT.PUT_LINE('Contrato: ' || prof.Contrato);
        END LOOP;
    END ConsultarProfesor;

END PKG_PROFESOR;
/

--(PACKTAGE BODY) ACUDIENTE:
CREATE OR REPLACE PACKAGE BODY PKG_ACUDIENTE IS

    PROCEDURE AdicionarAcudiente(
        Cedula IN VARCHAR2,
        Nombre IN VARCHAR2,
        CorreoElectronico IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Acudiente (Cedula, Nombre, CorreoElectronico)
        VALUES (TO_NUMBER(Cedula), Nombre, CorreoElectronico);
    END AdicionarAcudiente;


    PROCEDURE EliminarAcudiente(
        Cedula IN VARCHAR2
    ) IS
    BEGIN
        DELETE FROM Acudiente
        WHERE Cedula = TO_NUMBER(Cedula);
    END EliminarAcudiente;


    PROCEDURE ModificarAcudiente(
        Cedula IN VARCHAR2,
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Acudiente
        SET Nombre = Nombre
        WHERE Cedula = TO_NUMBER(Cedula);
    END ModificarAcudiente;


    PROCEDURE ConsultarAcudiente(
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        FOR a IN (
            SELECT Cedula, Nombre, CorreoElectronico
            FROM Acudiente
            WHERE UPPER(Nombre) LIKE '%' || UPPER(Nombre) || '%'
        ) LOOP
            DBMS_OUTPUT.PUT_LINE('Cedula: ' || a.Cedula);
            DBMS_OUTPUT.PUT_LINE('Nombre: ' || a.Nombre);
            DBMS_OUTPUT.PUT_LINE('Correo: ' || a.CorreoElectronico);
            DBMS_OUTPUT.PUT_LINE('------------------------');
        END LOOP;
    END ConsultarAcudiente;

END PKG_ACUDIENTE;
/

--(PACKTAGE BODY) PERSONAL_ADMINISTRATIVO
CREATE OR REPLACE PACKAGE BODY PKG_PERSONAL_ADMINISTRATIVO IS

    PROCEDURE AdicionarPersonalAdministrativo(
        Usuario IN VARCHAR2,
        Cargo IN VARCHAR2,
        Nombre IN VARCHAR2,
        FechaContrato IN DATE,
        CorreoElectronico IN VARCHAR2,
        ExperienciaLaboral IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Usuario (UsuarioID, Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral)
        VALUES (TO_NUMBER(Usuario), Nombre, FechaContrato, CorreoElectronico, ExperienciaLaboral);

        INSERT INTO PersonalAdministrativo (Cargo, Usuario)
        VALUES (Cargo, TO_NUMBER(Usuario));
    END AdicionarPersonalAdministrativo;


    PROCEDURE ModificarPersonalAdministrativo(
        Usuario IN VARCHAR2,
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Usuario
        SET Nombre = Nombre
        WHERE UsuarioID = TO_NUMBER(Usuario);
    END ModificarPersonalAdministrativo;


    PROCEDURE EliminarPersonalAdministrativo(
        Usuario IN VARCHAR2,
        Nombre IN VARCHAR2,
        Cargo IN VARCHAR2
    ) IS
    BEGIN
        DELETE FROM PersonalAdministrativo
        WHERE Usuario = TO_NUMBER(Usuario)
          AND Cargo = Cargo;

        DELETE FROM Usuario
        WHERE UsuarioID = TO_NUMBER(Usuario)
          AND Nombre = Nombre;
    END EliminarPersonalAdministrativo;


    PROCEDURE ConsultarPersonalAdministrativo(
        Nombre IN VARCHAR2
    ) IS
    BEGIN
        FOR p IN (
            SELECT u.UsuarioID, u.Nombre, u.CorreoElectronico, u.FechaContrato, pa.Cargo
            FROM Usuario u
            JOIN PersonalAdministrativo pa ON u.UsuarioID = pa.Usuario
            WHERE u.Nombre = Nombre
        ) LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || p.UsuarioID);
            DBMS_OUTPUT.PUT_LINE('Nombre: ' || p.Nombre);
            DBMS_OUTPUT.PUT_LINE('Correo: ' || p.CorreoElectronico);
            DBMS_OUTPUT.PUT_LINE('Fecha Contrato: ' || p.FechaContrato);
            DBMS_OUTPUT.PUT_LINE('Cargo: ' || p.Cargo);
            DBMS_OUTPUT.PUT_LINE('---');
        END LOOP;
    END ConsultarPersonalAdministrativo;

END PKG_PERSONAL_ADMINISTRATIVO;
/
