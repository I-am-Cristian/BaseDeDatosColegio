CREATE OR REPLACE PACKAGE PKG_PERSONALADMINISTRATIVO AS
  -- PROFESORES
  PROCEDURE AdicionarProfesor(
    Usuario VARCHAR2, 
    Especializacion VARCHAR2, 
    Contrato CHAR, 
    Nombre VARCHAR2, 
    FechaContrato DATE, 
    CorreoElectronico VARCHAR2, 
    ExperienciaLaboral VARCHAR2
  );

  PROCEDURE ModificarProfesor(
    Usuario VARCHAR2, 
    Nombre VARCHAR2
  );

  PROCEDURE EliminarProfesor(
    Usuario VARCHAR2
  );

  PROCEDURE ConsultarProfesor(
    Nombre VARCHAR2, 
    C_PROFESOR OUT SYS_REFCURSOR
  );

  -- ESTUDIANTES
  PROCEDURE AdicionarEstudiante(
    EstudianteID VARCHAR2, 
    FechaNacimiento DATE, 
    Direccion VARCHAR2, 
    Telefono VARCHAR2, 
    CorreoElectronico VARCHAR2
  );

  PROCEDURE ModificarEstudiante(
    EstudianteID VARCHAR2, 
    Nombre VARCHAR2
  );

  PROCEDURE EliminarEstudiante(
    EstudianteID VARCHAR2
  );

  PROCEDURE ConsultarEstudiante(
    EstudianteID VARCHAR2, 
    Nombre VARCHAR2, 
    C_ESTUDIANTE OUT SYS_REFCURSOR
  );

  -- PERSONAL ADMINISTRATIVO
  PROCEDURE AdicionarPersonalAdministrativo(
    Usuario VARCHAR2, 
    Cargo VARCHAR2, 
    Nombre VARCHAR2, 
    FechaContrato DATE, 
    CorreoElectronico VARCHAR2, 
    ExperienciaLaboral VARCHAR2
  );

  PROCEDURE ModificarPersonalAdministrativo(
    Usuario VARCHAR2, 
    Nombre VARCHAR2
  );

  PROCEDURE EliminarPersonalAdministrativo(
    Usuario VARCHAR2
  );

  PROCEDURE ConsultarPersonalAdministrativo(
    Nombre VARCHAR2, 
    C_PERSONAL OUT SYS_REFCURSOR
  );

  -- ACUDIENTES
  PROCEDURE AdicionarAcudiente(
    Cedula VARCHAR2, 
    Nombre VARCHAR2, 
    CorreoElectronico VARCHAR2
  );

  PROCEDURE ModificarAcudiente(
    Cedula VARCHAR2, 
    Nombre VARCHAR2
  );

  PROCEDURE EliminarAcudiente(
    Cedula VARCHAR2
  );

  PROCEDURE ConsultarAcudiente(
    Nombre VARCHAR2, 
    C_ACUDIENTE OUT SYS_REFCURSOR
  );
END PKG_PERSONALADMINISTRATIVO;
/
