--- PAQUETE: PKG_PROFESOR

CREATE OR REPLACE PACKAGE PKG_PROFESOR AS
  PROCEDURE AdicionarCalificaciones(Asignatura VARCHAR2, Profesor VARCHAR2, FechaEvaluacion DATE, Opinion XMLTYPE);
  PROCEDURE ConsultarCalificaciones(NombreAsignatura VARCHAR2, EstudianteID VARCHAR2, Nombre VARCHAR2);
  PROCEDURE ModificarCalificaciones(NombreAsignatura VARCHAR2, FechaEvaluacion DATE);
  PROCEDURE EliminarCalificaciones(AsignaturaId VARCHAR2, ProfesorId VARCHAR2);
END PKG_PROFESOR;
/

CREATE OR REPLACE PACKAGE BODY PKG_PROFESOR AS
  PROCEDURE AdicionarCalificaciones(Asignatura VARCHAR2, Profesor VARCHAR2, FechaEvaluacion DATE, Opinion XMLTYPE) IS
  BEGIN
    NULL;
  END;

  PROCEDURE ConsultarCalificaciones(NombreAsignatura VARCHAR2, EstudianteID VARCHAR2, Nombre VARCHAR2) IS
  BEGIN
    NULL;
  END;

  PROCEDURE ModificarCalificaciones(NombreAsignatura VARCHAR2, FechaEvaluacion DATE) IS
  BEGIN
    NULL;
  END;

  PROCEDURE EliminarCalificaciones(AsignaturaId VARCHAR2, ProfesorId VARCHAR2) IS
  BEGIN
    NULL;
  END;
END PKG_PROFESOR;
/


--- PAQUETE: PKG_ESTUDIANTE

CREATE OR REPLACE PACKAGE PKG_ESTUDIANTE AS
  PROCEDURE ConsultarCalificaciones(NombreAsignatura VARCHAR2, EstudianteID VARCHAR2);
  PROCEDURE ConsultarEstudiante(EstudianteID VARCHAR2);
END PKG_ESTUDIANTE;
/

CREATE OR REPLACE PACKAGE BODY PKG_ESTUDIANTE AS
  PROCEDURE ConsultarCalificaciones(NombreAsignatura VARCHAR2, EstudianteID VARCHAR2) IS
  BEGIN
    NULL;
  END;

  PROCEDURE ConsultarEstudiante(EstudianteID VARCHAR2) IS
  BEGIN
    NULL;
  END;
END PKG_ESTUDIANTE;
/


--- PAQUETE: PKG_ACUDIENTE

CREATE OR REPLACE PACKAGE PKG_ACUDIENTE AS
  PROCEDURE ConsultarCalificaciones(NombreAsignatura VARCHAR2, EstudianteID VARCHAR2);
  PROCEDURE ConsultarEstudiante(EstudianteID VARCHAR2);
END PKG_ACUDIENTE;
/

CREATE OR REPLACE PACKAGE BODY PKG_ACUDIENTE AS
  PROCEDURE ConsultarCalificaciones(NombreAsignatura VARCHAR2, EstudianteID VARCHAR2) IS
  BEGIN
    NULL;
  END;

  PROCEDURE ConsultarEstudiante(EstudianteID VARCHAR2) IS
  BEGIN
    NULL;
  END;
END PKG_ACUDIENTE;
/

=
--- PAQUETE: PKG_PERSONALADMINISTRATIVO

CREATE OR REPLACE PACKAGE PKG_PERSONALADMINISTRATIVO AS
  PROCEDURE AdicionarProfesor(Usuario VARCHAR2, Especializacion VARCHAR2, Contrato CHAR, Nombre VARCHAR2, FechaContrato DATE, CorreoElectronico VARCHAR2, ExperienciaLaboral VARCHAR2);
  PROCEDURE ModificarProfesor(Usuario VARCHAR2, Nombre VARCHAR2);
  PROCEDURE EliminarProfesor(Usuario VARCHAR2);
  PROCEDURE ConsultarProfesor(Nombre VARCHAR2);

  PROCEDURE AdicionarEstudiante(EstudianteID VARCHAR2, FechaNacimiento DATE, Direccion VARCHAR2, Telefono VARCHAR2, CorreoElectronico VARCHAR2);
  PROCEDURE ModificarEstudiante(EstudianteID VARCHAR2, Nombre VARCHAR2);
  PROCEDURE EliminarEstudiante(EstudianteID VARCHAR2);
  PROCEDURE ConsultarEstudiante(EstudianteID VARCHAR2, Nombre VARCHAR2);

  PROCEDURE AdicionarPersonalAdministrativo(Usuario VARCHAR2, Cargo VARCHAR2, Nombre VARCHAR2, FechaContrato DATE, CorreoElectronico VARCHAR2, ExperienciaLaboral VARCHAR2);
  PROCEDURE ModificarPersonalAdministrativo(Usuario VARCHAR2, Nombre VARCHAR2);
  PROCEDURE EliminarPersonalAdministrativo(Usuario VARCHAR2);
  PROCEDURE ConsultarPersonalAdministrativo(Nombre VARCHAR2);

  PROCEDURE AdicionarAcudiente(Cedula VARCHAR2, Nombre VARCHAR2, CorreoElectronico VARCHAR2);
  PROCEDURE ModificarAcudiente(Cedula VARCHAR2, Nombre VARCHAR2);
  PROCEDURE EliminarAcudiente(Cedula VARCHAR2);
  PROCEDURE ConsultarAcudiente(Nombre VARCHAR2);
END PKG_PERSONALADMINISTRATIVO;
/

CREATE OR REPLACE PACKAGE BODY PKG_PERSONALADMINISTRATIVO AS
  PROCEDURE AdicionarProfesor(Usuario VARCHAR2, Especializacion VARCHAR2, Contrato CHAR, Nombre VARCHAR2, FechaContrato DATE, CorreoElectronico VARCHAR2, ExperienciaLaboral VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ModificarProfesor(Usuario VARCHAR2, Nombre VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE EliminarProfesor(Usuario VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ConsultarProfesor(Nombre VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE AdicionarEstudiante(EstudianteID VARCHAR2, FechaNacimiento DATE, Direccion VARCHAR2, Telefono VARCHAR2, CorreoElectronico VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ModificarEstudiante(EstudianteID VARCHAR2, Nombre VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE EliminarEstudiante(EstudianteID VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ConsultarEstudiante(EstudianteID VARCHAR2, Nombre VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE AdicionarPersonalAdministrativo(Usuario VARCHAR2, Cargo VARCHAR2, Nombre VARCHAR2, FechaContrato DATE, CorreoElectronico VARCHAR2, ExperienciaLaboral VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ModificarPersonalAdministrativo(Usuario VARCHAR2, Nombre VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE EliminarPersonalAdministrativo(Usuario VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ConsultarPersonalAdministrativo(Nombre VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE AdicionarAcudiente(Cedula VARCHAR2, Nombre VARCHAR2, CorreoElectronico VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ModificarAcudiente(Cedula VARCHAR2, Nombre VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE EliminarAcudiente(Cedula VARCHAR2) IS
  BEGIN NULL; END;

  PROCEDURE ConsultarAcudiente(Nombre VARCHAR2) IS
  BEGIN NULL; END;
END PKG_PERSONALADMINISTRATIVO;
/